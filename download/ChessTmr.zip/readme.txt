----------------------------------------------------------------------
          Chess Timer v1.0  *FREEWARE* - 2002-10-03
----------------------------------------------------------------------

Author: Remy Sharp

        E-mail: remy@ihatemusic.com
        http://www.ihatemusic.com/palm


===============
CONTENTS
===============
1. Overview
2. Installation
3. Instructions
4. Other Software
5. Disclaimer

-----------
1. Overview
-----------
This is an ultra light weight Chess Timer (only 6K). Simple to use
and effective. The 'move complete' button is nice and big so you can
use your finger whilst playing those exciting speed chess games!


---------------
2. Installation
---------------
This archive contains the following files:

README.TXT 	- This file
CHESSTMR.PRC    - Program file

Use palm install tool to install the file chesstmr.prc and then tap on
the icon called "Chess Timer" on your palm.


---------------
3. Instructions
---------------
Once you've installed the app on to your palm, start it up.

Select the game preferences for the speed chess game, and tap start.
The timers for each player will count down as the game goes on.
Tapping or pressing with your finger, on the 'Move Done' will set the
next player to make their move.  The looser is the player who ran out
of time.

If you experience any problems, please drop me an email and let me
know your Palm OS, model and what you were doing so that I can try to
fix it ASAP - remy@ihatemusic.com.

Otherwise, enjoy, and watch this space for a few more interesting
light weight apps.


-----------------
4. Other Software
-----------------

- Interrupt Me!
Interrupt Me! is a simple to use, small app that allows you to set up
multiple profiles of alarms with different associated alarm sounds.
== see http://www.ihatemusic.com/palm/interrupt.html for details

- Marbles Squared
Marbles is a totally addictive puzzle game for your palm that doesn't
eat all your memory! For less than 10K of your precious Palm RAM
you're going to get a great and simple game that you'll find hard to
put down. == see http://www.ihatemusic.com/palm/marbles2.html for
details


Up coming software/ideas:
- Dev Stats
A program to keep track of how many downloads your app has had over
the entire Internet and read any reviews

- Travel Pal
Simple to use travel time planner for use with buses, trains and any
other modes of transport.

-------------
5. Disclaimer
-------------
You may distribute copies of Chess Timer, but only with this file.

I am not responsible for any damage or loss of data caused by this
software. If you encounter errors, please send me a report and I will
do my best to help
======================================================================

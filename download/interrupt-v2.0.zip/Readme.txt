----------------------------------------------------------------------
          Interrupt Me! v 2.0  *FREEWARE* - 2002-07-21
----------------------------------------------------------------------

Author: Remy Sharp

        E-mail: remy@ihatemusic.com
        http://www.ihatemusic.com/palm


===============
CONTENTS
===============
1. Overview
2. Installation
3. Instructions
4. History
5. Other Software
6. Disclaimer

-----------
1. Overview
-----------
Interrupt Me! is a simple to use, small app that allows you to set up
multiple profiles of alarms with different associated alarm sounds.
When you're spending your lunch reading the latest e-book you've downloaded
on to your palm, you might over run, so Interrupt Me! will pop up and tell
you to get your ass back to work - or what ever you want to use it for :)

Interrupt Me! is also perfect for setting alert tones for taking medicine,
using the phone alert to remember to make a phone call and bird chirps for
meetings.


---------------
2. Installation
---------------
This archive contains the following files:

README.TXT 	- This file
INTERRUPT_ME.PRC- Program file

If you have an existing version of Interrupt Me! installed, please delete
the original version - if you don't some very strange things could happen
with the records of your alarms!

Use palm install tool to install the file interrupt_me.prc and then tap on 
the icon called "Interrupt Me" on your palm.


---------------
3. Instructions
---------------
Once you've installed the app on to your palm, start it up.

Right, at the top you can name the different profiles, once you have given
the profile a name, you can use the right arrow to create another profile,
an so on.  Use the arrows to navigate back and forth.

Once you enter the values they will be saved to the profile by default.

You can then set the alarm, by tapping the appropriate button, and then
get on with what ever you want to do elsewhere on your palm.

If at any point you want to cancel the alarm, return to Interrupt Me! and
tap on 'Clean Alarm' - it doesn't matter which profile you are in, it will
clear it either way.

If you experience any problems, please drop me an email and let me know
your Palm OS, model and what you were doing so that I can try to fix it
ASAP - remy@ihatemusic.com.

Otherwise, enjoy, and watch this space for a few more interesting light
weight apps.


----------
4. History
----------
Version v2.0  (2002-07-21)
- Feature - multiple interrupts.  This means if you set one after
  the other, you will receive both timely interrupts.
- Feature - visual count down to the next interrupt.
- Feature - profile deletion (from menu).
- Feature - countdown and scheduled interrupts.  For example you can set an 
  interrupt to run at a specific time of day, as well as the standard count down.
- Feature - wnooze option when the interrupt pops up.

Version v2.0b  (2002-07-15)
- Feature - you can select different sounds for different audible alerts.
- Update - complete change of database structure and code design.

Version v1.1  (2002-06-06)
- Feature - added option for audible alert.
- Feature - added edit menu (not really a feature - but I thought I've got
  to write something here!)
- Fix - crashed palm when any action was run when  - sorry :(

Version v1.0  (2002-05-21)
- Initial version - my first palm app out on the net!!! Watch out Bill
  Gates :-)


-----------------
5. Other Software
-----------------

- Chess Timer
A simple straight forward two player chess timer.  Quick to use for those who
want to play against the clock.
== see http://www.ihatemusic.com/palm/chess.html for details


-------------
6. Disclaimer
-------------
You may distribute copies of Interrupt Me!, but only with this file.

I am not responsible for any damage or loss of data caused by this
software. If you encounter errors, please send me a report.
======================================================================

----------------------------------------------------------------------
          Interrupt Me! v 2.25  *FREEWARE* - 2002-11-02
----------------------------------------------------------------------

Author: Remy Sharp

        E-mail: remy@ihatemusic.com
        http://www.ihatemusic.com/palm


===============
CONTENTS
===============
1. Overview
2. Installation
3. Instructions
4. History
5. Other Software
6. Disclaimer

-----------
1. Overview
-----------
Interrupt Me! is a simple to use, small app that allows you to set up
multiple profiles of alarms with different associated alarm sounds.
When you're spending your lunch reading the latest e-book you've downloaded
on to your palm, you might over run, so Interrupt Me! will pop up and tell
you to get your ass back to work - or what ever you want to use it for :)

Interrupt Me! is also perfect for setting alert tones for taking medicine,
using the phone alert to remember to make a phone call and bird chirps for
meetings.


---------------
2. Installation
---------------
This archive contains the following files:

README.TXT 	- This file
INTERRUPT_[language].PRC- Program file

If you have an existing version of Interrupt Me! installed, please delete
the original version - if you don't some very strange things could happen
with the records of your alarms!

Use palm install tool to install the file interrupt_[language].prc and then
tap on the icon called "Interrupt Me" on your palm.


---------------
3. Instructions
---------------
Once you've installed the app on to your palm, start it up.

Right, at the top you can name the different profiles, once you have given
the profile a name, you can use the right arrow to create another profile,
an so on.  Use the arrows to navigate back and forth.

Once you enter the values they will be saved to the profile by default.

You can then set the alarm, by tapping the appropriate button, and then
get on with what ever you want to do elsewhere on your palm.

If at any point you want to cancel the alarm, return to Interrupt Me! and
tap on 'Clean Alarm' - it doesn't matter which profile you are in, it will
clear it either way.

If you experience any problems, please drop me an email and let me know
your Palm OS, model and what you were doing so that I can try to fix it
ASAP - remy@ihatemusic.com.

Otherwise, enjoy, and watch this space for a few more interesting light
weight apps.


----------
4. History
----------
Version v2.2  (2002-11-02)
- Feature - repeat scheduled alarms, ie. for medicine taking, etc.
- Feature - repeat of sound once the popup alert is open (ie. for morning
  alarms)
- Feature - optional backlight on alert
- Feature - overrun indicator
- Update - navigation improvements: up/down buttons, delete icon
- Update - better error checking and a few other minor changes
- Added - french translation by Antoine <websearch@wanadoo.fr>
- Added - polish translation by Pawel <papa@acn.waw.pl>

IMPORTANT NOTE: I have used the last 8 characters of the note (whose size 
was 150 characters) for the repeat and a few other features.  The note is 
now 142 characters.  If you had any Interrupt Me! messages that were over 
142 characters you will need to delete and reinstall Interrupt Me! - 
otherwise you should be able to upgrade without having to reinstall.

Version v2.1  (2002-08-23)
- Feature - new options: default snooze times and repeat alarm sound
- Update - reads system preference for date format (to avoid UK and US conflicts)
- Update - reduces the app size (a little!)
- Update - backs up database when you hotsync
- Fix - a few small bugs (count down appearing over menu, clearing alerts)
- Fix - tried to make more compatible with Palm OS 3.0 and over

Version v2.0  (2002-07-21)
- Feature - multiple interrupts.  This means if you set one after
  the other, you will receive both timely interrupts.
- Feature - visual count down to the next interrupt.
- Feature - profile deletion (from menu).
- Feature - countdown and scheduled interrupts.  For example you can set an
  interrupt to run at a specific time of day, as well as the standard count down.
- Feature - wnooze option when the interrupt pops up.

Version v2.0b  (2002-07-15)
- Feature - you can select different sounds for different audible alerts.
- Update - complete change of database structure and code design.

Version v1.1  (2002-06-06)
- Feature - added option for audible alert.
- Feature - added edit menu (not really a feature - but I thought I've got
  to write something here!)
- Fix - crashed palm when any action was run when  - sorry :(

Version v1.0  (2002-05-21)
- Initial version - my first palm app out on the net!!! Watch out Bill
  Gates :-)


-----------------
5. Other Software
-----------------

- Marbles Squared
Marbles is a totally addictive puzzle game for your palm that doesn't
eat all your memory! For less than 10K of your precious Palm RAM
you're going to get a great and simple game that you'll find hard to
put down. == see http://www.ihatemusic.com/palm/marbles2.html for details

- Chess Timer
A simple straight forward two player chess timer.  Quick to use for those who
want to play against the clock.
== see http://www.ihatemusic.com/palm/chess.html for details

Up coming software/ideas:
- Dev Stats
A program to keep track of how many downloads your app has had over the entire
Internet and read any reviews

- Travel Pal
Simple to use travel time planner for use with buses, trains and any other
modes of transport.

-------------
6. Disclaimer
-------------
You may distribute copies of Interrupt Me!, but only with this file.

I am not responsible for any damage or loss of data caused by this
software. If you encounter errors, please send me a report.
======================================================================
